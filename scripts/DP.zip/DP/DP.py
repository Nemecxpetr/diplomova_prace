"""
Module: DP
Author: Bc. Petr Nemec

This script is realizing the testing and accesing of the pipeline functions of my master's thesis [1]
(https://github.com/Nemecxpetr/diplomova_prace).

Task: 


Reference:

[1] NĚMEC, Petr. Score-to-audio synchronization of music interpretations [online]. 
    Brno, 2024 [cit. 2024-03-01]. Available from: https://www.vut.cz/studenti/zav-prace/detail/159304. 
    Master's Thesis. Vysoké učení technické v Brně, Fakulta elektrotechniky a komunikačních technologií, 
    Department of Telecommunications. Supervisor Matěj Ištvánek.
    
[2] MUELLER, Meinard and ZALKOW, Frank: FMP Notebooks: Educational Material for Teaching and Learning Fundamentals of Music Processing.
    Proceedings of the International Conference on Music Information Retrieval (ISMIR), Delft, The Netherlands, 2019.
"""
from librosa import feature
import Handler as handle
from Handler.MIDI_handler import midi_test
from SYNC.DTW import create_synced_object_from_MIDIfile, dtw_test
from pathlib import Path
from libfmp.b.b_sonification import sonify_chromagram_with_signal, list_to_chromagram
from synctoolbox.feature.csv_tools import df_to_pitch_features
from synctoolbox.feature.chroma import pitch_to_chroma
from scipy.io.wavfile import write
import numpy as np
from IPython.display import Audio
import matplotlib.pyplot as plt
from synctoolbox.feature.csv_tools import df_to_pitch_features
from synctoolbox.feature.chroma import pitch_to_chroma

from SYNC.evaluator import evaluate_all_versions_in_preset_folder

import librosa
import os

import seaborn as sns
import pandas as pd
import soundfile as sf

def pipeline(filenames, 
             folder, 
             debug : bool = False, 
             feature_type : str = 'stft',
             verbose : bool = False,
             figure_format : str = 'pdf'):
    """ MAIN PIPELINE
    This is the function where the main pipeline is created as described in the thesis [1]
        1. Load input files as sequences 𝑥, 𝑦 of some sort;
        2. Convert the sequences 𝑋, 𝑌 to a common mid-representation format – chroma
            features;
        3. Compute the optimal warping path;
        4. Extrapolate the obtained path and gain exact beginning and end times/tics
            of musical elements in the original symbolic representation;
        5. Change the times of the musical instances in a copy of the original symbolic
            data and export the sequence as a new synchronized MIDI file.
    """
    for i, filename in enumerate(filenames):
        # 1. STEP - choose destinations for input and output MIDI and AUDIO data        
        input_midi_path = f'../../data/input/MIDI/{folder}/{filenames[0]}.mid'
        input_audio_path = f'../../data/input/audio/{folder}/{filename}.wav'
        output_midi_path = f'../../data/output/midi/{folder}/{feature_type}/s_{filename}.mid'
        csv = f'../../data/csv/{filename}.csv'
        output_audio_path = f'../../data/output/audio/{folder}/{feature_type}/{filename}.wav'                    # stereo audio for subjective eval 
        output_sonified_midi_path = f'../../data/output/audio/{folder}/{feature_type}/s_{filename}_sonified.wav' # syncrhonized midi sonified

        # Ensure parent directories exist
        Path(input_midi_path).parent.mkdir(parents=True, exist_ok=True)
        Path(input_audio_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_midi_path).parent.mkdir(parents=True, exist_ok=True)
        Path(csv).parent.mkdir(parents=True, exist_ok=True)
        Path(output_audio_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_sonified_midi_path).parent.mkdir(parents=True, exist_ok=True)

        # 2. STEP - SYNCHRONIZE 
        # TODO: pad input midi with some zero notes at beggining (done) and at end
        handle.midi_to_csv(midi=input_midi_path, csv_path=csv, debug=debug)
        synced_midi, audio_chroma, audio_hop = create_synced_object_from_MIDIfile(input_midi_path, input_audio_path, output_midi_path, csv, feature_type=feature_type, verbose=verbose,)

        # 3. STEP - is it working? VISUAL COMPARISON
        feature_rate = 48000 / audio_hop
        # Load midi and export it to chroma representation
        df_midi_in = handle.midi_to_csv(midi=input_midi_path)
        df_midi_synced = handle.midi_to_csv(midi=output_midi_path)
        f_chroma_in = pitch_to_chroma(f_pitch=df_to_pitch_features(df_midi_in, feature_rate=feature_rate))
        f_chroma_out = pitch_to_chroma(f_pitch=df_to_pitch_features(df_midi_synced, feature_rate=feature_rate))
        
        # Compare the chroma representations
        chromas         = [f_chroma_in, f_chroma_out, audio_chroma]
        chroma_names    = ['Input MIDI', 'Output MIDI', 'Audio Interpretation']
        fig_chroma, _   = handle.compare_chroma(chromas, chroma_names, audio_hop=audio_hop, verbose=verbose)
        fig_piano_roll, _ = handle.compare_midi(input_midi_path, output_midi_path, audio_chroma, audio_hop=audio_hop, verbose=verbose)
        
        # Save the figure
        if fig_piano_roll is not None:
            save_path = f'../../data/output/figures/{folder}/{feature_type}/{filename}_comparison.{figure_format}'
            Path(save_path).parent.mkdir(parents=True, exist_ok=True)
            fig_piano_roll.savefig(save_path, format=figure_format)
            plt.close(fig_piano_roll)
        # Save the chroma figure
        if fig_chroma is not None:
            save_path = f'../../data/output/figures/{folder}/{feature_type}/{filename}_chroma_comparison.{figure_format}'
            Path(save_path).parent.mkdir(parents=True, exist_ok=True)
            fig_chroma.savefig(save_path, format=figure_format)
            plt.close(fig_chroma)

        print(f"SYNCHRONIZATION of {folder} with {feature_type} features: {round(((i+1)/len(filenames))*100, ndigits=3)}% DONE")

        # Sonification evaluation     
        Fs = 48000
        x, Fs = librosa.load(path=input_audio_path, sr=Fs)
        feature_rate = Fs / audio_hop
        
        # Use fluidsynth-based sonification for MIDI 
        sonified_midi = handle.audio_handler.sonify_midi(
                            midi_file=output_midi_path,  # already generated synced MIDI
                            output_audio_file=output_sonified_midi_path,
                            soundfont="../../data/soundfonts/FluidR3_GM.sf2",
                            sample_rate=48000
                        )

        # Load both signals
        audio_orig, _ = librosa.load(input_audio_path, sr=Fs)
        audio_synth, _ = librosa.load(output_audio_path, sr=Fs)

        # Match lengths using zero-padding
        max_len = max(len(audio_orig), len(audio_synth))
        audio_orig_padded = np.pad(audio_orig, (0, max_len - len(audio_orig)), mode='constant')
        audio_synth_padded = np.pad(audio_synth, (0, max_len - len(audio_synth)), mode='constant')

        # Stack into stereo
        audio_stereo = np.stack([audio_orig_padded, audio_synth_padded], axis=1)

        handle.audio_handler.write_audio(output_audio_path, audio_stereo, Fs)

def dataset_preset(preset, conv=False):
    """Choose filenames and folder presets for the dataset described in [1]
    Args:   
        preset (str): The name of the dataset preset to use.
            # Dataset Presets:
            #    #    preset = 'gymnopedie'
            #    #    preset = 'unravel'
            #    #    preset = 'albeniz'
            #    #    preset = 'summertime'
            #    #    preset = 'messiaen'
        conv (bool): Whether to convert audio files to wav format.
    Returns:
        tuple: A tuple containing the folder name and a list of filenames.
    """
    if preset == 'gymnopedie':         
            #folder = 'gymnopedie'
            #filenames = ['gymnopedie no1_1', 'gymnopedie no1_2', 'gymnopedie no1 khatia']
            # Convert audio files to wav format
            #for filename in filenames:
            #    handle.audio_handler.convert_to_wav(f'../../data/input/audio/{folder}/{filename}.m4a', f'../../data/input/audio/{folder}/{filename}.wav', format='m4a')

            folder = 'gymnopedie'
            filenames = ['gymnopedie_no1', 'gymnopedie_no1_1', 'gymnopedie_no1_2', 'gymnopedie_no1_khatia', 'gymnopedie_no1_3', 'gymnopedie_no1_4']       
            conv_format = None
    elif preset == 'unravel':
            folder = 'unravel'
            filenames = ['unravel']
            conv_format = None
    elif preset ==  'albeniz':
            folder = 'albeniz'
            filenames = ['alb_se5', 'alb_se5_1', 'alb_se5_2', 'alb_se5_3']
            conv_format = 'mp3'
            # for filename in filenames:
            #    handle.audio_handler.convert_to_wav(f'../../data/input/audio/{folder}/{filename}.mp3', f'../../data/input/audio/{folder}/{filename}.wav', format='mp3')
    elif preset == 'summertime':
        folder = 'summertime'
        filenames = ['summertime','summertime_1', 'summertime_2']
        conv_format = 'mp3'
        #for filename in filenames:
        #    handle.audio_handler.convert_to_wav(f'../../data/input/audio/{folder}/{filename}.mp3', f'../../data/input/audio/{folder}/{filename}.wav', format='mp3')
    elif preset == 'messiaen':
        folder = 'messiaen'
        filenames = ['messiaen_le_banquet_celeste', 'messiaen_le_banquet_celeste_1', 'messiaen_le_banquet_celeste_2']
        conv_format = 'm4a' 
    elif preset == 'test_2':
        folder = 'tests/test_2'
        filenames = ['test_2', 'test_2_1', 'test_2_2']
        conv_format = None
    else:
        print('Unknown preset')
        return None, None

    if (conv_format is not None) & conv:
        for filename in filenames:
            handle.audio_handler.convert_to_wav(f'../../data/input/audio/{folder}/{filename}.{conv_format}', f'../../data/input/audio/{folder}/{filename}.wav', format=conv_format)
  
    return folder, filenames

def ultimate_test(feature_type : str = 'stft'):
    """Ultimate test of the pipeline for all data in the dataset at on go.
    Arg:
        feature_type : str = available types are: 'stft', 'cens', 'cqt', 'cqt_1'

    """
    for preset in ['gymnopedie', 'unravel', 'albeniz', 'summertime', 'messiaen']:
        folder, filenames = dataset_preset(preset, conv=False)
        debug = False # debuging argument passed to other functions 
        verbose = False # argument passed to other functions for activating graph visualization of sync process
        pipeline(filenames, folder, debug, feature_type=feature_type, verbose=verbose)
        print(f"Pipeline for {preset} using {feature_type} representations DONE")

def plot_evaluation_results(presets, csv_dir="../../data/eval/results/csv", normalize=False, visualize=False):
    """
    Plot evaluation metrics for a list of presets from CSV files and save the plots as EPS.

    Args:
        presets (list): List of preset names (e.g., ['unravel', 'albeniz']).
        csv_dir (str): Path to the directory containing evaluation CSV files.
        normalize (bool): Whether to normalize the metric values.
        visualize (bool): Whether to display the plots interactively.
    """
    import pandas as pd
    import seaborn as sns
    import matplotlib.pyplot as plt
    from pathlib import Path

    csv_dir = Path(csv_dir)
    all_dfs = []
    for preset in presets:
        path = csv_dir / f"{preset}_full_evaluation.csv"
        if path.exists():
            df = pd.read_csv(path)
            df["Preset"] = preset
            df = df.rename(columns={
                "DTW Score": "DTW_Score",
                "MAE": "Mean_Absolute_Error",
                "XCorr Score": "XCorr_Score",
                "XCorr Lag": "XCorr_Lag",
                "Peak Alignment Error": "Peak_Alignment_Error"
            })
            all_dfs.append(df)

    if not all_dfs:
        print("No evaluation data found.")
        return

    df_all = pd.concat(all_dfs, ignore_index=True)
    df_melted = df_all.melt(
        id_vars=["Preset", "Version"],
        value_vars=["DTW_Score", "Mean_Absolute_Error", "XCorr_Score", "Peak_Alignment_Error"],
        var_name="Metric",
        value_name="Score"
    )

    if normalize:
        df_melted["Score"] = df_melted.groupby("Metric")["Score"].transform(
            lambda x: (x - x.min()) / (x.max() - x.min()) if x.max() != x.min() else 0
        )

    figure_dir = Path("../../data/eval/results/figures")
    figure_dir = Path("../../data/eval/results/figures")
    figure_dir.mkdir(parents=True, exist_ok=True)
    metrics = ["DTW_Score", "Mean_Absolute_Error", "XCorr_Score", "Peak_Alignment_Error"]

    for metric in metrics:
        plt.figure(figsize=(8, 4))
        subset = df_melted[df_melted["Metric"] == metric]

        # Box plot for distribution
        sns.boxplot(
            data=subset,
            x="Preset",
            y="Score",
            hue="Version",
            palette="pastel",
            dodge=True,
            fliersize=0  # Hide outliers, we show them with stripplot instead
        )

        # Add jittered individual points
        sns.stripplot(
            data=subset,
            x="Preset",
            y="Score",
            hue="Version",
            dodge=True,
            marker="o",
            alpha=0.6,
            linewidth=0.5,
            edgecolor="gray"
        )

        title_suffix = " (Normalized)" if normalize else ""
        plt.title(f"{metric.replace('_', ' ')}{title_suffix}")
        plt.ylabel("Normalized Score" if normalize else "Score")
        plt.grid(True, linestyle="--", alpha=0.6)
        plt.tight_layout()
        figure_path = figure_dir / f"plot_points_line_{metric.lower()}.pdf"
        plt.savefig(figure_path, format="pdf")
        if visualize: plt.show()
        plt.close()

    print("Saved all plots to:", figure_dir)


# What we try to achieve is a function synchronize_MIDI_with_audio()
if __name__ == "__main__":
    # 1. choose the testfile names 
    #    # Naming convention in the dataset is that the first audio file has the same name 
    #    as the midifile to be synced with.
    #    # The others are numbered
    # Dataset Presets:
    #    #    preset = 'gymnopedie'
    #    #    preset = 'unravel'
    #    #    preset = 'albeniz'
    #    #    preset = 'summertime'
    #    #    preset = 'messiaen'
    #    #    preset = 'test_2'

    folder, filenames = dataset_preset('summertime', conv=False)
     
    debug = False # debuging argument passed to other functions 
    verbose = False # argument passed to other functions for activating graph visualization of sync process
    
    # Running whole pipeline from function
    # Feature types: 'stft', 'cens', 'cqt', 'cqt_1'
    #pipeline(filenames,folder, debug, feature_type = 'cqt_1', verbose=verbose)
    #pipeline(filenames, folder, debug, feature_type = 'stft', verbose=verbose)

    # Ultimate test of the pipeline for all data in the dataset at on go.
    # NOTE: Running this function takes a long time and is not recommended for testing purposes.
    #ultimate_test(feature_type = 'stft') 
    #print(f'Everything for STFT features was succesfully synchronized!')
    #ultimate_test(feature_type = 'cqt_1')
    #print(f'Everything for CQT features was succesfully synchronized!')

    # EVALUATION OF THE PIPELINE
    # This part is used for evaluation of the pipeline and is not part of the main pipeline.
    # evaluate_preset_bulk(
    #     original_audio='../../data/input/audio/summertime/summertime.wav',
    #     midi_paths=[
    #         '../../data/output/MIDI/summertime/s_summertime.mid',
    #         '../../data/output/MIDI/summertime/s_summertime_1.mid',
    #         '../../data/output/MIDI/summertime/s_summertime_2.mid'
    #     ],
    #     preset_name='summertime',
    #     soundfont='../../data/soundfonts/FluidR3_GM.sf2',
    #     visualize=True
    # )

    # Evaluate dual versions of the pipeline
    # evaluate_dual_versions(
    #     original_audio_base='../../data/input/audio/summertime/summertime.wav',
    #     midi_base_path='../../data/output/MIDI/summertime',
    #     preset_name='summertime',
    #     soundfont='../../data/soundfonts/FluidR3_GM.sf2',
    #     visualize=True
    # )

    # Evaluate pipeline dual versions bulk for all presets
    # 'gymnopedie', 'unravel', 'albeniz', 'summertime', 'messiaen', 'test_2'
    # for preset in ['gymnopedie', 'unravel', 'albeniz', 'summertime', 'messiaen', 'test_2']:
    #     evaluate_all_versions_in_preset_folder(
    #         preset_name=preset,
    #         soundfont='../../data/soundfonts/FluidR3_GM.sf2',
    #         visualize=False, 
    #         downsample_factor=4,
    #         binarize=False,
    #         skip_sonification=True
    #     )
    # print(f'Evaluation of {preset} done!')

    # Graph visualization of the evaluation results
    plot_evaluation_results(
        presets=['unravel', 'albeniz', 'summertime', 'messiaen', 'gymnopedie'],
        csv_dir="../../data/eval/results/csv",
        normalize=False,
        visualize=True
    )


    # TESTING PARTS OF THE SCRIPT
    #dtw_test(filenames[0], True)
    #midi_test(debug=True)


    # PRINTING GRAPHS FOR THESIS
    #filename = 'tests/test'
    #handle.visualizer.print_spectrum_for_thesis(filename)


    # Fun with cqt
    #x, sr = handle.read_audio('../../data/input/audio/krajina_v7-binaural_downmix-Stereo Out.wav')
    #handle.visualizer.plot_spectrogram(x, Fs = sr, feature_type = 'stft')


    # Print comparison of different chroma features
    # x, fs = handle.read_audio('../../data/input/audio/unravel/unravel.wav')
    # x = handle.audio_handler.to_mono(x)
    # N = 2048*2
    # H = N//2
    # fig, _ = handle.visualizer.compare_chroma_features(x, fs, H, N, verbose = False)

    # with open('../../data/output/figures/compare_chroma_features_unravel.png', "wb") as f:
    #     fig.savefig(f)
    #     plt.close(fig)