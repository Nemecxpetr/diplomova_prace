﻿"""
Module: audio_handler
Author: Petr Němec
License: 

Some functions were taken from or inspired by the FMP Notebooks (https://www.audiolabs-erlangen.de/FMP) and libfmp.
"""

from os import read
from pathlib import Path
import librosa
import soundfile as sf
from pydub import AudioSegment
import subprocess


def read_audio(path, Fs=None, mono=False):
    """Read an audio file into a np.ndarray.

    Args:
        path (str): Path to audio file
        Fs (scalar): Resample audio to given sampling rate. Use native sampling rate if None. (Default value = None)
        mono (bool): Convert multi-channel file to mono. (Default value = False)

    Returns:
        x (np.ndarray): Waveform signal
        Fs (scalar): Sampling rate
    """
    return librosa.load(path, sr=Fs, mono=mono)


def write_audio(path, x, Fs):
    """Write a signal (as np.ndarray) to an audio file.

    Args:
        path (str): Path to audio file
        x (np.ndarray): Waveform signal
        Fs (scalar): Sampling rate
    """
    sf.write(path, x, Fs)

def to_mono(x):
    """Convert multichanel audio to mono.
    Args:
        x (np.ndarray): Waveform signal
    Returns:
        x_mono (np.ndarray): Mono waveform signal
    """
    if len(x.shape) == 1:
        return x
    else:
        return librosa.to_mono(x)


def convert_to_wav(input_path, output_path, format='m4a'):
    """Converts input files from various formats to WAV format.
    Args:
        input_path (str): Path to input file
        output_path (str): Path to output WAV file
    Returns:
        None
    """

    sound = AudioSegment.from_file(input_path, format=format)
    file_handle = sound.export(output_path, format='wav')

from pathlib import Path
import subprocess
from Handler.audio_handler import read_audio

def sonify_midi(midi_file: str or Path, 
                output_audio_file: str or Path,
                soundfont: str or Path = Path("../../data/soundfonts/FluidR3_GM.sf2"),
                sample_rate: int = 44100):
    """
    Convert a MIDI file to audio using FluidSynth and return the audio as a numpy array.

    Args:
        midi_file (str | Path): Path to the MIDI file.
        output_audio_file (str | Path): Path where the synthesized audio will be saved.
        soundfont (str | Path): Path to the soundfont file.
        sample_rate (int): Sampling rate in Hz.

    Returns:
        np.ndarray: Mono audio waveform.
    """
    midi_file = str(midi_file)
    output_audio_file = str(output_audio_file)
    soundfont = str(soundfont)

    command = [
        'fluidsynth', '-ni',
        '-F', output_audio_file,
        '-T', 'wav',
        '-r', str(sample_rate),
        '-o', 'audio.driver=null',
        soundfont, midi_file
    ]

    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"FluidSynth failed: {e}") from e

    # Load and return mono audio
    return read_audio(output_audio_file, Fs=sample_rate, mono=True)
